<?php
// function theme_enqueue_scripts() {
// wp_enqueue_style( 'bootstrap', get_template_directory_uri().'/assets/css/bootstrap.css');
// wp_enqueue_style( 'styles', get_template_directory_uri().'/assets/css/styles.css', array('bootstrap'),'all' );
//
//
// wp_enqueue_script( 'bootstrap', get_template_directory_uri().'/js/bootstrap.js', array('jquery'),false, true );
// }
// add_action( 'wp_enqueue_scripts', 'theme_enqueue_scripts' );
?>
