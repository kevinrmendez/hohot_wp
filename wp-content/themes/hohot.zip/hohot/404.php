<?php get_header(); ?>

<div class="content error_404">
  <div class="error">
    <h1><?php _e('Page not found(404)','hohot'); ?></h1>
    <!-- <p><strong><?php _e(' The website you requested was not found','hohot') ?>.</strong></p> -->
    <p><?php _e('We are sorry to inform you that the requested page does not exist','hohot'); ?> </p>
  </div>
</div>


<?php get_footer(); ?>
